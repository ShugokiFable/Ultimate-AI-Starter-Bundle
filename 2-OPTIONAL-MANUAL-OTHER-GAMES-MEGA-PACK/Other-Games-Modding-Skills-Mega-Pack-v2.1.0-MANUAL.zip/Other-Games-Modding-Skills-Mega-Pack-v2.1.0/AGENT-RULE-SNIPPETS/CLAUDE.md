# Optional multi-game modding rules

Before the first write:

1. Load `game-mod-memory`.
2. Load `game-mod-tool-router`; for Minecraft also load `minecraft-java-modding`.
3. Load `game-mod-versioned-workspace`.
4. Fully duplicate the current semantic-version snapshot.
5. Update `CURRENT.txt`, `VERSION.md`, and `CHANGELOG.md`.
6. Edit only the new version.

Never edit deployed game files or overwrite the parent version.
Never invent framework APIs, hook signatures, offsets, IDs, paths, or schemas.
Use exact installed-version evidence and official sources.
One writer owns each tightly coupled plugin, package, DLL, or generated output set.
