# Kimi Code manual installation

Copy all folders from `skills` into `%KIMI_CODE_HOME%\skills\`.
Default: `%USERPROFILE%\.kimi-code\skills\`.
Append `AGENT-RULE-SNIPPETS\KIMI-AGENTS.md` to `%KIMI_CODE_HOME%\AGENTS.md`.
