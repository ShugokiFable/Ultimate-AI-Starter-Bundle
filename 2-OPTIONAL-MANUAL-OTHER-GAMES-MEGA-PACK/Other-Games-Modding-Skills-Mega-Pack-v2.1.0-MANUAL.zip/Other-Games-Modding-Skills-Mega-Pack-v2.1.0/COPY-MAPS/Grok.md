# Grok Build manual installation

Copy all folders from `skills` into `%GROK_HOME%\skills\`.
Default: `%USERPROFILE%\.grok\skills\`.
Merge `AGENT-RULE-SNIPPETS\GROK-AGENTS.md` as workspace `AGENTS.md`.
