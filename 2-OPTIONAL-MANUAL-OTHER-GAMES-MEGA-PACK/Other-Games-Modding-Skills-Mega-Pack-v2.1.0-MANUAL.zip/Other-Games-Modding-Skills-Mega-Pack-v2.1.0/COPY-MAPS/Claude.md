# Claude Code manual installation

Copy all folders from `skills` into `%CLAUDE_CONFIG_DIR%\skills\`.
Default: `%USERPROFILE%\.claude\skills\`.
Append `AGENT-RULE-SNIPPETS\CLAUDE.md` to the global or project `CLAUDE.md`.
