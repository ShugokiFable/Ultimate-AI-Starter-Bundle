# Codex manual installation

Copy every skill folder from `skills\` into:

```text
%CODEX_HOME%\skills\
```

Default:

```text
%USERPROFILE%\.codex\skills\
```

Append `AGENT-RULE-SNIPPETS\CODEX-AGENTS.md` to the applicable global or
workspace `AGENTS.md`.

Do not install the provider-specific pack in a cross-tool shared skill directory.
