# Hermes Agent manual installation

Copy all folders from `skills` into `%HERMES_HOME%\skills\`.
Merge `AGENT-RULE-SNIPPETS\HERMES-WORKSPACE-AGENTS.md` as workspace `AGENTS.md`.
Do not put project procedures in `SOUL.md`.
