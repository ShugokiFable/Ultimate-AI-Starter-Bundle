# Other Games Modding Skills Ultra Mega Pack v2.1.0

**Manual installation only.**

This package contains 70 reusable mod-development skills. It uses
the same rollback-first philosophy as the Skyrim pack.

## The rule that applies to every game

Before the first edit, the AI must fully duplicate the current semantic-version
folder, update `CURRENT.txt`, create `VERSION.md`, start `CHANGELOG.md`, record
the AI/model/reasoning, and edit only the new snapshot.

## Minecraft is now a full ecosystem

The pack separately handles:

- Fabric;
- Forge;
- NeoForge;
- Quilt;
- multiloader/Architectury architecture;
- Mixins, MixinExtras, access wideners, and access transformers;
- components, capabilities, data attachments, codecs, and persistence;
- networking and dedicated servers;
- registries, tags, recipes, loot, datagen, and worldgen;
- rendering and GeckoLib;
- config/menu APIs;
- JEI, REI, EMI;
- Curios, Trinkets, Accessories;
- KubeJS and CraftTweaker;
- optional library APIs;
- porting, testing, and release matrices.

## Expanded game coverage

Minecraft Java, Fallout 4, Starfield, Cyberpunk 2077, Risk of Rain 2,
Palworld, Baldur's Gate 3, Divinity: Original Sin 2, Stardew Valley,
The Witcher 3, Satisfactory, Bannerlord, RimWorld, Stellaris, Hearts of Iron IV,
Crusader Kings III, Europa Universalis IV, Victoria 3, Factorio, Terraria,
Project Zomboid, Valheim, Subnautica, Lethal Company, Oxygen Not Included,
Don't Starve Together, Noita, Cities: Skylines II, BeamNG.drive, Arma 3, DayZ,
Space Engineers, Slay the Spire, Kerbal Space Program 1, Barotrauma,
Garry's Mod, XCOM 2, No Man's Sky, generic Unity/BepInEx/Harmony, generic
Unreal/UE4SS, and an unknown-game fallback.

## Installation

Open `COPY-MAPS` and follow the file for Codex, Claude, Grok, Kimi, or Hermes.
The package does not modify native AI memory or provider configuration.

## Included skill folders

- `arma3-modding`
- `baldurs-gate3-modding`
- `bannerlord-modding`
- `barotrauma-modding`
- `beamng-modding`
- `cities-skylines2-modding`
- `ck3-modding`
- `cyberpunk2077-modding`
- `dayz-modding`
- `divinity-original-sin2-modding`
- `dont-starve-together-modding`
- `dotnet-harmony-patching`
- `eu4-modding`
- `factorio-modding`
- `fallout4-modding`
- `game-mod-assets`
- `game-mod-code-review`
- `game-mod-crash-diagnostics`
- `game-mod-development`
- `game-mod-facts`
- `game-mod-load-order-compatibility`
- `game-mod-memory`
- `game-mod-native-plugin`
- `game-mod-packaging`
- `game-mod-performance-profiling`
- `game-mod-reworking`
- `game-mod-runtime-patching`
- `game-mod-ship-gate`
- `game-mod-tool-router`
- `game-mod-unknown-game-fallback`
- `game-mod-versioned-workspace`
- `garrys-mod-modding`
- `hoi4-modding`
- `kerbal-space-program-modding`
- `lethal-company-modding`
- `minecraft-content-datagen-worldgen`
- `minecraft-data-components-attachments`
- `minecraft-fabric-quilt-modding`
- `minecraft-forge-neoforge-modding`
- `minecraft-java-game-modding`
- `minecraft-java-modding`
- `minecraft-library-api-integrations`
- `minecraft-mixins-access-control`
- `minecraft-modpack-scripting`
- `minecraft-multiloader-architectury`
- `minecraft-networking-persistence`
- `minecraft-rendering-animation`
- `minecraft-testing-porting-release`
- `no-mans-sky-modding`
- `noita-modding`
- `oxygen-not-included-modding`
- `palworld-modding`
- `paradox-clausewitz-jomini-modding`
- `project-zomboid-modding`
- `rimworld-harmony-modding`
- `risk-of-rain2-modding`
- `satisfactory-sml-modding`
- `slay-the-spire-modding`
- `space-engineers-modding`
- `stardew-valley-modding`
- `starfield-modding`
- `stellaris-modding`
- `subnautica-nautilus-modding`
- `terraria-tmodloader-modding`
- `unity-bepinex-harmony`
- `unreal-ue4ss-modding`
- `valheim-jotunn-modding`
- `victoria3-modding`
- `witcher3-redkit-modding`
- `xcom2-modding`
