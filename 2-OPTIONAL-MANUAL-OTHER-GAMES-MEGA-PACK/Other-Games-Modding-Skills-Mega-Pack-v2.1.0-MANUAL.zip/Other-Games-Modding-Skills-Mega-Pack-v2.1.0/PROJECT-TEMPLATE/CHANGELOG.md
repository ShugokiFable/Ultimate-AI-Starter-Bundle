# Changelog

## 1.0.0
- Parent: none
- AI: pending
- Planned change: initial release
- Changed files: pending
- Validation: pending
- Runtime status: assistant-claimed
- Unresolved: pending
