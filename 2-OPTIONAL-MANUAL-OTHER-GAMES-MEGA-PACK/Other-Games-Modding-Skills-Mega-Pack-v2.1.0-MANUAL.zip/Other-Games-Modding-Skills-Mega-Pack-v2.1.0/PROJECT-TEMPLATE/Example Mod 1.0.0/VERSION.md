# Example Mod 1.0.0

- Parent: none
- Created:
- AI:
- Planned change: initial release
- Previous snapshot untouched: N/A
