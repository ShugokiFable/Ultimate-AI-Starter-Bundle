# Workspace ownership

- Owner application:
- Authoritative root:
- Created:
- Transfers:
