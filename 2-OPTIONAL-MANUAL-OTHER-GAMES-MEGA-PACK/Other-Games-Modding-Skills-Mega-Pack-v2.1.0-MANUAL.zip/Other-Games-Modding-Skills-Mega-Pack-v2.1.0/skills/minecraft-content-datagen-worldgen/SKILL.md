---
name: minecraft-content-datagen-worldgen
description: Develop Minecraft registries, tags, recipes, loot, advancements, data packs, resource packs, data generation,
  world generation, biomes, dimensions, and TerraBlender integrations.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Content, data generation, and world generation

Use deterministic data generation for registries, models, blockstates, tags,
recipes, loot tables, advancements, language files, and other generated assets.

## Worldgen

Pin the target version's codec/schema and determine whether the feature belongs
in vanilla data packs, loader APIs, TerraBlender, or custom code. Validate seeds,
server generation, upgrade of existing worlds, biome-source interactions,
datapack reload, and generated-resource completeness.

Never hand-edit generated output without updating its source generator.

Primary references:

- https://docs.fabricmc.net/develop/
- https://docs.minecraftforge.net/
- https://docs.neoforged.net/
- https://github.com/Glitchfiend/TerraBlender


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
