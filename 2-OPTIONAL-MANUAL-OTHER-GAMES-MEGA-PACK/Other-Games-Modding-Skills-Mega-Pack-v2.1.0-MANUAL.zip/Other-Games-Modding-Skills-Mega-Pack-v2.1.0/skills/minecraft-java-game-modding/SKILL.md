---
name: minecraft-java-game-modding
description: Compatibility alias for the expanded Minecraft Java ecosystem router.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Minecraft Java compatibility alias

Use `minecraft-java-modding` as the primary router. This alias remains so older
agent instructions do not fail after the mega-pack upgrade.

Do not implement from this page alone.
