---
name: game-mod-tool-router
description: First router for modding a supported or unknown non-Skyrim game. Selects the generic workflow and the smallest
  applicable engine or game specialist set.
compatibility: Cross-platform where the selected game and toolchain support it
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Ultra multi-game modding router

Load `game-mod-memory` and `game-mod-versioned-workspace` before the first write.

## Core routing

| Task | Skills |
|---|---|
| New project | `game-mod-development`, game/framework specialist |
| Existing mod update | `game-mod-reworking`, specialist |
| Unknown game | `game-mod-unknown-game-fallback` |
| Native/managed plugin | `game-mod-native-plugin`, engine/framework specialist |
| Assets | `game-mod-assets`, game specialist |
| Crash | `game-mod-crash-diagnostics` |
| Packaging | `game-mod-packaging`, `game-mod-ship-gate` |
| Compatibility/load order | `game-mod-load-order-compatibility` |

## Game routing

### Minecraft

Use `minecraft-java-modding`, then the smallest loader/API specialists it selects.

### Creation Engine family

- Fallout 4: `fallout4-modding`
- Starfield: `starfield-modding`

### REDengine and Larian

- Cyberpunk 2077: `cyberpunk2077-modding`
- The Witcher 3: `witcher3-redkit-modding`
- Baldur's Gate 3: `baldurs-gate3-modding`
- Divinity: Original Sin 2: `divinity-original-sin2-modding`

### Unity and managed ecosystems

- Risk of Rain 2: `risk-of-rain2-modding`
- Valheim: `valheim-jotunn-modding`
- Subnautica: `subnautica-nautilus-modding`
- Lethal Company: `lethal-company-modding`
- Oxygen Not Included: `oxygen-not-included-modding`
- RimWorld: `rimworld-harmony-modding`
- Stardew Valley: `stardew-valley-modding`
- Kerbal Space Program 1: `kerbal-space-program-modding`
- Generic Unity: `unity-bepinex-harmony`

### Unreal ecosystems

- Palworld: `palworld-modding`
- Satisfactory: `satisfactory-sml-modding`
- XCOM 2: `xcom2-modding`
- Generic Unreal: `unreal-ue4ss-modding`

### Paradox strategy

Load `paradox-clausewitz-jomini-modding`, then:

- Stellaris: `stellaris-modding`
- Hearts of Iron IV: `hoi4-modding`
- Crusader Kings III: `ck3-modding`
- Europa Universalis IV: `eu4-modding`
- Victoria 3: `victoria3-modding`

### Data/script-friendly games

- Factorio: `factorio-modding`
- Terraria: `terraria-tmodloader-modding`
- Project Zomboid: `project-zomboid-modding`
- Don't Starve Together: `dont-starve-together-modding`
- Noita: `noita-modding`
- Garry's Mod: `garrys-mod-modding`
- Slay the Spire: `slay-the-spire-modding`
- Barotrauma: `barotrauma-modding`

### Official/editor/tool ecosystems

- Cities: Skylines II: `cities-skylines2-modding`
- BeamNG.drive: `beamng-modding`
- Arma 3: `arma3-modding`
- DayZ: `dayz-modding`
- Space Engineers: `space-engineers-modding`
- Bannerlord: `bannerlord-modding`
- No Man's Sky: `no-mans-sky-modding`


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.

