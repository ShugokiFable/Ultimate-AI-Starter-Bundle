---
name: minecraft-library-api-integrations
description: Integrate common Minecraft library mods and optional APIs including configs, mod menus, recipe viewers, accessories,
  guide books, and cross-loader utility libraries.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Minecraft library and API integrations

## Categories to inspect

### Configuration and menus

- loader-native config systems;
- Cloth Config;
- YetAnotherConfigLib;
- Mod Menu;
- other version-specific config screens.

### Recipe and item viewers

- JEI;
- REI;
- EMI.

These are viewer/plugin APIs, not recipe-authoring replacements.

### Accessories and equipment slots

- Curios;
- Trinkets;
- Accessories.

### Guide books and documentation

- Patchouli and loader/version-specific alternatives.

### Shared utility libraries

- Architectury;
- Balm;
- Bookshelf;
- Moonlight;
- Puzzles Lib;
- Resourceful Lib;
- Registrate;
- Porting Lib;
- other project-specific libraries.

## Rules

- Treat every integration as optional unless the mod intentionally requires it.
- Isolate adapters so the core mod loads when the optional API is absent.
- Never load client-only viewer/config classes on a dedicated server.
- Pin exact Maven coordinates and licenses from the upstream project.
- Avoid adding a large library for one trivial helper.

Representative primary repositories:

- https://github.com/mezz/JustEnoughItems
- https://github.com/shedaniel/RoughlyEnoughItems
- https://github.com/emilyploszaj/emi
- https://github.com/shedaniel/cloth-config
- https://github.com/illusivesoulworks/curios
- https://github.com/emilyploszaj/trinkets
- https://github.com/wisp-forest/accessories
- https://github.com/Fuzss/puzzles-lib


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
