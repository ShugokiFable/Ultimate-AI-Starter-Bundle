---
name: minecraft-data-components-attachments
description: Choose, implement, and migrate Minecraft persistent or synced data using loader-native attachments, Forge capabilities,
  components, data components, codecs, or supported library APIs.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Minecraft attached and persistent data

Possible systems vary by loader and version:

- vanilla data components and codecs;
- Fabric Data Attachment API;
- Cardinal Components API;
- Forge capabilities;
- NeoForge data attachments;
- Curios, Trinkets, or Accessories data owned by those APIs;
- saved data, entity data, block-entity data, chunk data, and world data.

For each field, define owner, lifetime, default, serialization codec, sync
direction, cloning/death behavior, dimension transfer, migration, and removal.

Never mix several ownership systems for the same data without an explicit
adapter and migration plan.

Primary references:

- https://docs.fabricmc.net/develop/data-attachments
- https://docs.minecraftforge.net/en/latest/datastorage/capabilities/
- https://docs.neoforged.net/
- https://wiki.fabricmc.net/community:library_mods


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
