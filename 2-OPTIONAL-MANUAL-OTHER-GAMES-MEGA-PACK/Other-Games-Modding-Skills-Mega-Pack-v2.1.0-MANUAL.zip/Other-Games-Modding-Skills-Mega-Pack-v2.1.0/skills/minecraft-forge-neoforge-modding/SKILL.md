---
name: minecraft-forge-neoforge-modding
description: Develop and port Minecraft mods using Forge or NeoForge while keeping their APIs, Gradle tooling, metadata, events,
  data systems, networking, and lifecycle separate.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Forge and NeoForge

Forge and NeoForge are related ecosystems, not interchangeable import namespaces.

## Verify

- exact loader branch and Minecraft version;
- ForgeGradle or NeoGradle/toolchain version;
- official/Mojang/Parchment mappings;
- mod metadata and dependency ranges;
- event bus and lifecycle;
- registries and deferred registration;
- sides and distribution safety;
- networking;
- Forge capabilities versus NeoForge data attachments or current equivalents;
- access transformers;
- configuration system;
- data generation and GameTest support.

Do not mechanically replace package names to port between Forge and NeoForge.
Compare official porting notes and source for the target release.

Primary sources:

- https://docs.minecraftforge.net/
- https://docs.neoforged.net/


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
