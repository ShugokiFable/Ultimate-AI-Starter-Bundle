---
name: minecraft-java-modding
description: Primary router for modern Minecraft Java mod development across Fabric, Forge, NeoForge, Quilt, multiloader projects,
  library APIs, data generation, networking, rendering, and modpack scripting.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Minecraft Java ecosystem router

Minecraft modding is a matrix, not one API.

## Resolve first

- Minecraft version, including whether the project uses the newer calendar-style
  version line or an older `1.x` line;
- Java version;
- loader and loader version;
- mappings namespace;
- Gradle plugin and build tool versions;
- client, dedicated server, or both;
- required and optional library mods;
- whether the project is single-loader or multiloader;
- source-set and generated-resource layout.

## Loader routing

| Target | Load these specialists |
|---|---|
| Fabric | `minecraft-fabric-quilt-modding` |
| Quilt | `minecraft-fabric-quilt-modding`, with Quilt/QSL verification |
| Forge | `minecraft-forge-neoforge-modding`, Forge branch |
| NeoForge | `minecraft-forge-neoforge-modding`, NeoForge branch |
| Several loaders | `minecraft-multiloader-architectury` |
| Mixins or private access | `minecraft-mixins-access-control` |
| Saved or synced data | `minecraft-data-components-attachments` |
| Packets and dedicated server | `minecraft-networking-persistence` |
| Registries, tags, recipes, loot, data generation | `minecraft-content-datagen-worldgen` |
| Models, renderers, animation | `minecraft-rendering-animation` |
| Config, mod menu, recipe viewer, accessories | `minecraft-library-api-integrations` |
| KubeJS/CraftTweaker/modpack scripts | `minecraft-modpack-scripting` |
| Porting and release | `minecraft-testing-porting-release` |

## Common ecosystem categories

The exact library list is version and loader dependent. Common categories
include Fabric API, Forge APIs, NeoForge APIs, Quilt APIs, Architectury,
SpongePowered Mixin, MixinExtras, Parchment mappings, Cardinal Components,
loader-native attachments/capabilities, Curios, Trinkets, Accessories, Cloth
Config, YACL, Mod Menu, GeckoLib, JEI, REI, EMI, Patchouli, TerraBlender,
KubeJS, CraftTweaker, Registrate, Balm, Bookshelf, Moonlight, Puzzles Lib,
Resourceful Lib, and other library mods.

A familiar name is not proof that the requested Minecraft and loader version is
supported. Inspect the exact project release, Gradle coordinates, license,
side requirements, and API source.


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
