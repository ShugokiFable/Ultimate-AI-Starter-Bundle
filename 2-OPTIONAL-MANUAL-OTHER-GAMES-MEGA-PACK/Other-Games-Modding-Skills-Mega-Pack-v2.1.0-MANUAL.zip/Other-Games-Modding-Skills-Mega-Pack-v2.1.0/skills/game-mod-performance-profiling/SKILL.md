---
name: game-mod-performance-profiling
description: Profile and optimize mod CPU, GPU, memory, I/O, allocation, network, and startup costs without speculative hardware
  claims.
compatibility: Cross-platform where the selected game and toolchain support it
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---


# Performance profiling

Measure frame time, hook frequency, allocations, I/O, asset memory, shader/cooker
cost, network traffic, startup, and save/load time before optimizing.
Optimize the actual hot path and document before/after evidence.


## Non-negotiable laws

- Never edit a deployed game directory, active mod-manager staging folder, save, profile, or framework installation as the project source.
- Resolve the exact game build, storefront, runtime, loader, framework versions, dependency graph, and packaging format before implementation.
- Never invent API names, hook signatures, offsets, asset identifiers, manifest keys, paths, serialization fields, or compiler syntax.
- Prefer official documentation, upstream source, exact installed files, generated SDKs, and known-good local examples.
- A build or parser pass is not runtime proof.
- Preserve the previous working version and make the new version reproducible.
- Record every command, changed file, validation result, unresolved risk, and runtime status.
