---
name: paradox-clausewitz-jomini-modding
description: Generic workflow for Paradox Clausewitz/Jomini game mods including descriptors, script databases, events, triggers,
  effects, localisation, graphics, replace_path, dependencies, and launcher packaging.
compatibility: Use only with exact game, loader, framework, and runtime versions verified for the active project
metadata:
  version: 2.0.0
  updated: '2026-07-20'
  library: overseer-ultra-multi-game-modding-skills
---

# Paradox Clausewitz and Jomini foundations

This skill supports routing for Stellaris, Hearts of Iron IV, Crusader Kings III,
Europa Universalis IV, and Victoria 3. Their script vocabularies are not
interchangeable.

## Common layers

- `.mod` and descriptor metadata;
- supported version and dependencies;
- namespaces and IDs;
- events, decisions, missions, focuses, situations, journals, or game-specific
  systems;
- scripted triggers, effects, values, modifiers, and localisation;
- on_actions;
- common/history/map/gfx/gui/interface directories;
- `replace_path`;
- launcher and Workshop packaging;
- checksum and multiplayer implications.

## Rules

- Never infer a trigger or effect from another Paradox game.
- Prefer additive files and uniquely namespaced IDs.
- Use `replace_path` only when the total replacement is intentional.
- Validate every localisation key and script database error.
- Test with `-debug_mode` and game-specific validation logs where supported.


## Mandatory version snapshot before the first write

Every update begins by fully duplicating the current semantic-version snapshot.

```text
<OwnerRoot>\<Mod Name>\
├── CHANGELOG.md
├── CURRENT.txt
├── WORKSPACE_OWNERSHIP.md
├── <Mod Name> 1.0.0\
│   └── VERSION.md
├── <Mod Name> 1.0.1\
│   └── VERSION.md
└── <Mod Name> 1.1.0\
    └── VERSION.md
```

Before editing:

1. Read `CURRENT.txt`, `CHANGELOG.md`, and ownership.
2. Choose patch, minor, or major.
3. Fully copy the current snapshot into the new version folder.
4. Update `CURRENT.txt`.
5. Create the new `VERSION.md`.
6. Start the changelog entry with AI application, model, reasoning mode, parent
   version, goal, and intended files.
7. Edit only the new snapshot.
8. Record changed files, commands, validation, failed approaches, runtime status,
   and unresolved risks.

The parent remains immutable for rollback and binary comparison.


## Non-negotiable controls

- Resolve the exact game build, storefront, engine/runtime, mod loader, mappings,
  framework versions, dependencies, and package format before implementation.
- Never invent APIs, class names, hooks, signatures, offsets, IDs, XML keys,
  script effects, reflected properties, asset paths, or serialization fields.
- Prefer current official documentation, upstream source, exact installed files,
  generated SDKs, decompiled assemblies, and known-good local examples.
- Deployed game directories, active manager staging, profiles, saves, and
  framework installations are read-only.
- Build, parser, loader, semantic, save, multiplayer, and runtime validation are
  separate gates.
- One writer owns each tightly coupled DLL, mod JAR, plugin, package, generated
  output set, or release archive.
