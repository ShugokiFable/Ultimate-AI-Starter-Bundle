"""Claude-specific provider helpers."""

from .runtime import (
    DEFAULT_API_URL,
    REMOTE_CONTROL_BASE_URL_ENV,
    REMOTE_CONTROL_GATED_MIN_VERSION,
    REMOTE_CONTROL_NON_SUBSCRIPTION_ENV,
    REMOTE_CONTROL_SIBLING_GATE_NOTE,
    TOOL_SEARCH_DEFAULT,
    TOOL_SEARCH_ENV,
    detect_claude_code_version,
    is_custom_anthropic_base_url,
    parse_claude_code_version,
    proxy_base_url,
    remote_control_applies_to_auth,
    remote_control_gate_active,
    remote_control_gate_message,
    remote_control_sibling_gate_note,
)
from .vscode import (
    claude_user_settings_path,
    configure_vscode_claude_settings,
    remove_vscode_claude_settings,
    vscode_claude_proxy_url,
)

__all__ = [
    "claude_user_settings_path",
    "configure_vscode_claude_settings",
    "remove_vscode_claude_settings",
    "vscode_claude_proxy_url",
    "DEFAULT_API_URL",
    "REMOTE_CONTROL_BASE_URL_ENV",
    "REMOTE_CONTROL_GATED_MIN_VERSION",
    "REMOTE_CONTROL_NON_SUBSCRIPTION_ENV",
    "REMOTE_CONTROL_SIBLING_GATE_NOTE",
    "TOOL_SEARCH_DEFAULT",
    "TOOL_SEARCH_ENV",
    "detect_claude_code_version",
    "is_custom_anthropic_base_url",
    "parse_claude_code_version",
    "proxy_base_url",
    "remote_control_applies_to_auth",
    "remote_control_gate_active",
    "remote_control_gate_message",
    "remote_control_sibling_gate_note",
]
