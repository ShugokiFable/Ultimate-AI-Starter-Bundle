"""Copilot-specific provider helpers."""

from .vscode import (
    configure_vscode_proxy_settings,
    remove_vscode_proxy_settings,
    vscode_proxy_url,
    vscode_settings_path,
    vscode_user_dir,
)
from .wrap import (
    build_launch_env,
    copilot_model_from_args,
    default_wire_api_for_model,
    detect_running_proxy_backend,
    is_auto_model,
    model_configured,
    model_prefers_responses_api,
    provider_key_source,
    query_proxy_config,
    resolve_provider_type,
    strip_auto_model_args,
    validate_configuration,
)

__all__ = [
    "build_launch_env",
    "copilot_model_from_args",
    "default_wire_api_for_model",
    "detect_running_proxy_backend",
    "is_auto_model",
    "model_prefers_responses_api",
    "model_configured",
    "provider_key_source",
    "query_proxy_config",
    "resolve_provider_type",
    "strip_auto_model_args",
    "validate_configuration",
    "configure_vscode_proxy_settings",
    "remove_vscode_proxy_settings",
    "vscode_proxy_url",
    "vscode_settings_path",
    "vscode_user_dir",
]
